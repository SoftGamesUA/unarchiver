//
//  SGUnarchiver.m
//  NewUnarchiver
//
//  Created by Женя Коваль on 29.02.12.
//  Copyright (c) 2012 SoftGames. All rights reserved.
//

#import "Unarchiver.h"

#import "Unrar4iOS.h"

@implementation Unarchiver

@synthesize delegate = _delegate;

- (bool) addToZipWithPath:(NSString *)zipPath files:(NSArray *)files password:(NSString *)password
{
    if (!zipPath || !files) return false;
    if ([files count] == 0) return false;
    
	ZipArchive *zip = [[ZipArchive alloc] init];
    zip.delegate = self;
    
    if (password)
    {
        if (![zip CreateZipFile2:zipPath Password:password]) return false;
    }
    else
    {
        if (![zip CreateZipFile2:zipPath]) return false;
    }
    
    for (NSString *fileToZip in files)
    {
        NSDictionary *properties = [[NSFileManager defaultManager] attributesOfItemAtPath:fileToZip error:nil];
        if ([properties objectForKey:NSFileType] == NSFileTypeDirectory) [zip addFolderToZip:fileToZip pathPrefix:nil];
        else [zip addFileToZip:fileToZip newname:[fileToZip lastPathComponent]];
    }
    [zip release];

    return true;
}

- (bool) unZipArchiveWithPath:(NSString*)zipPath toPath:(NSString *)pathToUnZip password:(NSString *)password
{
    if (!zipPath || !pathToUnZip) return false;
    
    ZipArchive *zip = [[ZipArchive alloc] init];
    zip.delegate = self;
    bool rezultZIP;
    
    if (password) rezultZIP = [zip UnzipOpenFile: zipPath Password:password];
    else rezultZIP = [zip UnzipOpenFile: zipPath];
    
    if (rezultZIP == false) return false;
    else
    {
        [_pathToUnZip release]; [_zipPath release];
        _pathToUnZip = [[NSString alloc] initWithString:pathToUnZip];
        _zipPath = [[NSString alloc] initWithString:zipPath];
        
        if (![zip UnzipFileTo:pathToUnZip overWrite:false]) return false;
        [zip UnzipCloseFile];
	}
    [zip release];
    return true;

}

- (bool) unRarArchiveWithPath:(NSString*)rarPath toPath:(NSString *)pathToUnRar
{
	if (!rarPath || !pathToUnRar) return false;
    
    Unrar4iOS *unrar = [[Unrar4iOS alloc] init];
        
    if (![unrar unrarOpenFile:rarPath]) return false;
    
    BOOL isDir = true;
    NSFileManager *fm = [NSFileManager defaultManager];
    if(![fm fileExistsAtPath:pathToUnRar isDirectory:&isDir])	
        [fm createDirectoryAtPath:pathToUnRar withIntermediateDirectories:true attributes:nil error:nil];
    
    NSArray *files = [unrar unrarListFiles];
	for (NSString *fileName in files) 
	{
        NSMutableArray *fileNameComponents = (NSMutableArray*)[fileName componentsSeparatedByString:@"/"];
		if ([fileNameComponents count] > 1) 
		{
			NSString *directoryName = [NSString stringWithFormat:@"%@/%@", pathToUnRar, [fileName stringByDeletingLastPathComponent]];
			
  			if(![fm fileExistsAtPath:directoryName isDirectory:&isDir])	
                [fm createDirectoryAtPath:directoryName withIntermediateDirectories:true attributes:nil error:nil];
					
        }
				
        NSData *data = [unrar extractStream:fileName];
		if (![data writeToFile:[NSString stringWithFormat:@"%@/%@", pathToUnRar, fileName] atomically:YES]) return false;
    }
			
    if (![unrar unrarCloseFile]) return false;
    [unrar release];
    
    return true;
}

- (void)ErrorMessage:(NSString *)msg
{
    if ([msg isEqualToString:@"Failed to reading zip file"])
    {
        [[NSFileManager defaultManager] removeItemAtPath:_pathToUnZip error:nil];
        if (_delegate && [_delegate respondsToSelector:@selector(unZipError:)])
        {
            [_delegate unZipError:_zipPath];
        }
    }
}

- (void) dealloc
{
    [_pathToUnZip release];
    [_zipPath release];
    [super dealloc];
}

@end
